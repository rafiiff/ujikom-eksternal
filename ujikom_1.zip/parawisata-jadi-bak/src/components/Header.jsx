import React from "react";
import Navbar from "./Navbar";

export default function Header() {
  return (
    <header id="home">
      <Navbar />
      <div className="hero">
        <div className="container">
          <div className="box-hero">
            <div className="box">
              <h1>
                Taklukkan Selera Anda <br />
                dengan Kelezatan Sejati!
              </h1>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, autem?</p>
              <button>Selengkapnya</button>
            </div>
            <div className="box">
              <img src="/hero-makanan.jpeg" alt="" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
